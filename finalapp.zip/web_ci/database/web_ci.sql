/*
 Navicat Premium Dump SQL

 Source Server         : mysql57
 Source Server Type    : MySQL
 Source Server Version : 50716 (5.7.16-log)
 Source Host           : localhost:3306
 Source Schema         : web_ci

 Target Server Type    : MySQL
 Target Server Version : 50716 (5.7.16-log)
 File Encoding         : 65001

 Date: 19/06/2025 16:37:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for barang
-- ----------------------------
DROP TABLE IF EXISTS `barang`;
CREATE TABLE `barang`  (
  `barcode` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `harga` int(11) NULL DEFAULT NULL,
  `stock` int(11) NULL DEFAULT NULL,
  `id_group` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`barcode`) USING BTREE,
  INDEX `fk_id_group_barang`(`id_group`) USING BTREE,
  CONSTRAINT `fk_id_group_barang` FOREIGN KEY (`id_group`) REFERENCES `barang_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of barang
-- ----------------------------

-- ----------------------------
-- Table structure for barang_group
-- ----------------------------
DROP TABLE IF EXISTS `barang_group`;
CREATE TABLE `barang_group`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of barang_group
-- ----------------------------
INSERT INTO `barang_group` VALUES (1, 'Electronic');
INSERT INTO `barang_group` VALUES (2, 'Peralatan Rumah Tangga');

-- ----------------------------
-- Table structure for dokter
-- ----------------------------
DROP TABLE IF EXISTS `dokter`;
CREATE TABLE `dokter`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `notelp` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dokter
-- ----------------------------

-- ----------------------------
-- Table structure for jurusan
-- ----------------------------
DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE `jurusan`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of jurusan
-- ----------------------------
INSERT INTO `jurusan` VALUES (1, 'Sistem Informasi');
INSERT INTO `jurusan` VALUES (2, 'Teknik Informatika');
INSERT INTO `jurusan` VALUES (3, 'Teknik Mesin');

-- ----------------------------
-- Table structure for pasien
-- ----------------------------
DROP TABLE IF EXISTS `pasien`;
CREATE TABLE `pasien`  (
  `norm` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `notelp` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `alamat` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`norm`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pasien
-- ----------------------------

-- ----------------------------
-- Table structure for peserta_didik
-- ----------------------------
DROP TABLE IF EXISTS `peserta_didik`;
CREATE TABLE `peserta_didik`  (
  `nomor` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gender` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `no_telp` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id_jurusan` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`nomor`) USING BTREE,
  INDEX `fk_id_jurusan`(`id_jurusan`) USING BTREE,
  CONSTRAINT `fk_id_jurusan` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of peserta_didik
-- ----------------------------

-- ----------------------------
-- Table structure for rekammedik
-- ----------------------------
DROP TABLE IF EXISTS `rekammedik`;
CREATE TABLE `rekammedik`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NULL DEFAULT NULL,
  `visum` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tindakan` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `norm` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id_dokter` int(11) NULL DEFAULT NULL,
  `id_tindakan` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_pasien`(`norm`) USING BTREE,
  INDEX `fk_dokter`(`id_dokter`) USING BTREE,
  INDEX `fk_tindakan`(`id_tindakan`) USING BTREE,
  CONSTRAINT `fk_dokter` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pasien` FOREIGN KEY (`norm`) REFERENCES `pasien` (`norm`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tindakan` FOREIGN KEY (`id_tindakan`) REFERENCES `tindakan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of rekammedik
-- ----------------------------

-- ----------------------------
-- Table structure for tbl_menu
-- ----------------------------
DROP TABLE IF EXISTS `tbl_menu`;
CREATE TABLE `tbl_menu`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_menu
-- ----------------------------
INSERT INTO `tbl_menu` VALUES (1, 'Barang Group', 'Barang_group');
INSERT INTO `tbl_menu` VALUES (2, 'Barang', 'Barang');
INSERT INTO `tbl_menu` VALUES (3, 'Supplier', 'Supplier');
INSERT INTO `tbl_menu` VALUES (4, 'Jurusan', 'Jurusan');
INSERT INTO `tbl_menu` VALUES (5, 'Peserta Didik', 'Peserta');
INSERT INTO `tbl_menu` VALUES (6, 'Pembayaran', 'Bayar');
INSERT INTO `tbl_menu` VALUES (7, 'Jenis Pembayaran', 'Jenis_bayar');
INSERT INTO `tbl_menu` VALUES (8, 'Pasien', 'Pasien');
INSERT INTO `tbl_menu` VALUES (9, 'Dokter', 'Dokter');
INSERT INTO `tbl_menu` VALUES (10, 'Tindakan', 'Tindakan');
INSERT INTO `tbl_menu` VALUES (11, 'Rekam Medik', 'Rekam');

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pswd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `akses` enum('prodi','dosen','mahasiswa') CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'mahasiswa',
  `kelas` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '\'prodi\',\'dosen\',\'mahasiswa\'' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES (1, 'Sucipto,S.Kom,M.Kom', 'sucipto@gmail.com', 'prodi', 'prodi', NULL);
INSERT INTO `tbl_user` VALUES (2, 'Arie Nugroho, M.Kom, M.MM', 'arie@gmail.com', 'arie', 'dosen', NULL);
INSERT INTO `tbl_user` VALUES (3, 'Aidina Ristyawan, M.Kom', 'aidina@gmail.com', 'aidina', 'dosen', NULL);
INSERT INTO `tbl_user` VALUES (4, 'DHEO ABRILIANT', 'deo@gmail.com', 'deo', 'mahasiswa', '2A');
INSERT INTO `tbl_user` VALUES (5, 'ANGGI PURWANTI', 'anggi@gmail.com', 'anggi', 'mahasiswa', '2B');
INSERT INTO `tbl_user` VALUES (6, 'Budi', 'budi@gmail.com', 'budi', 'mahasiswa', '2C');

-- ----------------------------
-- Table structure for tbl_user_menu
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user_menu`;
CREATE TABLE `tbl_user_menu`  (
  `id_user` int(11) NOT NULL DEFAULT 0,
  `id_menu` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_user`, `id_menu`) USING BTREE,
  INDEX `id_menu`(`id_menu`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_user_menu
-- ----------------------------
INSERT INTO `tbl_user_menu` VALUES (2, 1);
INSERT INTO `tbl_user_menu` VALUES (3, 1);
INSERT INTO `tbl_user_menu` VALUES (4, 1);
INSERT INTO `tbl_user_menu` VALUES (2, 2);
INSERT INTO `tbl_user_menu` VALUES (4, 2);
INSERT INTO `tbl_user_menu` VALUES (2, 3);
INSERT INTO `tbl_user_menu` VALUES (4, 3);
INSERT INTO `tbl_user_menu` VALUES (5, 4);
INSERT INTO `tbl_user_menu` VALUES (5, 5);
INSERT INTO `tbl_user_menu` VALUES (5, 6);
INSERT INTO `tbl_user_menu` VALUES (5, 7);
INSERT INTO `tbl_user_menu` VALUES (6, 8);
INSERT INTO `tbl_user_menu` VALUES (6, 9);
INSERT INTO `tbl_user_menu` VALUES (6, 10);
INSERT INTO `tbl_user_menu` VALUES (6, 11);

-- ----------------------------
-- Table structure for tindakan
-- ----------------------------
DROP TABLE IF EXISTS `tindakan`;
CREATE TABLE `tindakan`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tindakan
-- ----------------------------
INSERT INTO `tindakan` VALUES (1, 'Injeksi');
INSERT INTO `tindakan` VALUES (2, 'Rongsen');

SET FOREIGN_KEY_CHECKS = 1;


CREATE TABLE `pembayaran_jenis` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nama` VARCHAR(255) NOT NULL,
  `nominal` INT(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
