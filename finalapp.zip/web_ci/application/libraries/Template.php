<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Template
{

    var $template_data = array();
    function set($name, $value)
    {
        $this->template_data[$name] = $value;
    }

    // $this->load->view('template/dashboard');
    public function load($template, $view, $data = [])
    {
        $CI =& get_instance();
    
        // Jika belum ada menu, tambahkan otomatis berdasarkan user login
        if (!isset($data['menu']) && $CI->session->userdata('ses_id_user')) {
            $CI->load->model('Menu_model');
            $data['menu'] = $CI->Menu_model->getMenuByUser($CI->session->userdata('ses_id_user'));
        }
    
        $data['contents'] = $CI->load->view($view, $data, true);
        $CI->load->view($template, $data);
    }
    
}