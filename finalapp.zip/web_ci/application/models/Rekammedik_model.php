<?php
class Rekammedik_model extends CI_Model
{
    public function getAll()
    {
        return $this->db->select('r.*, p.nama as pasien, d.nama as dokter, t.nama as tindakan')
            ->from('rekammedik r')
            ->join('pasien p', 'r.norm = p.norm', 'left')
            ->join('dokter d', 'r.id_dokter = d.id', 'left')
            ->join('tindakan t', 'r.id_tindakan = t.id', 'left')
            ->get()->result();
    }

    public function getById($id)
    {
        return $this->db->get_where('rekammedik', ['id' => $id])->row();
    }

    public function insert($data)
    {
        $this->db->insert('rekammedik', [
            'tanggal'     => $data['tanggal'],
            'visum'       => $data['visum'],
            'tindakan'    => $data['tindakan'],
            'norm'        => $data['norm'],
            'id_dokter'   => $data['id_dokter'],
            'id_tindakan' => $data['id_tindakan']
        ]);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id)->update('rekammedik', [
            'tanggal'     => $data['tanggal'],
            'visum'       => $data['visum'],
            'tindakan'    => $data['tindakan'],
            'norm'        => $data['norm'],
            'id_dokter'   => $data['id_dokter'],
            'id_tindakan' => $data['id_tindakan']
        ]);
    }

    public function delete($id)
    {
        $this->db->delete('rekammedik', ['id' => $id]);
    }

    public function getPasien()
    {
        return $this->db->get('pasien')->result();
    }

    public function getDokter()
    {
        return $this->db->get('dokter')->result();
    }

    public function getTindakan()
    {
        return $this->db->get('tindakan')->result();
    }
    public function countAll()
{
    return $this->db->count_all('rekammedik');
}

public function countPasien()
{
    return $this->db->count_all('pasien');
}

public function countDokter()
{
    return $this->db->count_all('dokter');
}

public function countTindakan()
{
    return $this->db->count_all('tindakan');
}

public function getGrafikPerBulan()
{
    $this->db->select("MONTH(tanggal) as bulan, COUNT(*) as jumlah");
    $this->db->from("rekammedik");
    $this->db->group_by("MONTH(tanggal)");
    $query = $this->db->get()->result();

    $labels = [];
    $jumlah = [];
    foreach ($query as $row) {
        $labels[] = date('F', mktime(0, 0, 0, $row->bulan, 10)); // nama bulan
        $jumlah[] = $row->jumlah;
    }

    return [
        'bulan' => $labels,
        'jumlah' => $jumlah
    ];
}

public function grafikBulanan()
{
    $query = $this->db->query("
        SELECT MONTH(tanggal) as bulan, COUNT(*) as jumlah 
        FROM rekammedik 
        GROUP BY MONTH(tanggal) 
        ORDER BY bulan ASC
    ");

    $bulan = [];
    $jumlah = [];

    foreach ($query->result() as $row) {
        $bulan[] = date('M', mktime(0, 0, 0, $row->bulan, 1)); // contoh: Jan, Feb
        $jumlah[] = (int) $row->jumlah;
    }

    return ['bulan' => $bulan, 'jumlah' => $jumlah];
}

public function grafikTindakan()
{
    $this->db->select('t.nama as tindakan, COUNT(r.id) as jumlah');
    $this->db->from('rekammedik r');
    $this->db->join('tindakan t', 'r.id_tindakan = t.id', 'left');
    $this->db->group_by('t.id');
    $query = $this->db->get()->result();

    $labels = [];
    $jumlah = [];
    foreach ($query as $row) {
        $labels[] = $row->tindakan;
        $jumlah[] = (int)$row->jumlah;
    }
    return ['labels' => $labels, 'jumlah' => $jumlah];
}

public function getDokterTerbanyakPasien($limit = 5)
{
    $this->db->select('d.nama, COUNT(r.norm) as pasien_count');
    $this->db->from('rekammedik r');
    $this->db->join('dokter d', 'r.id_dokter = d.id', 'left');
    $this->db->group_by('r.id_dokter');
    $this->db->order_by('pasien_count', 'DESC');
    $this->db->limit($limit);
    return $this->db->get()->result();
}

public function getPasienTerbaru($limit = 5)
{
    // Jika ada kolom tanggal daftar pasien (misal 'tgl_daftar'), gunakan ini
    if ($this->db->field_exists('tgl_daftar', 'pasien')) {
        $this->db->order_by('tgl_daftar', 'DESC');
    } else if ($this->db->field_exists('id', 'pasien')) {
        // Jika tidak ada tanggal, urut berdasarkan id (asumsi auto increment)
        $this->db->order_by('id', 'DESC');
    } else {
        // Jika tidak ada keduanya, tetap urut berdasarkan norm (tapi ini kurang ideal)
        $this->db->order_by('norm', 'DESC');
    }
    $this->db->limit($limit);
    return $this->db->get('pasien')->result();
}


}