<?php
class Tindakan_model extends CI_Model
{
    public function getAll()
    {
        return $this->db->get('tindakan')->result();
    }

    public function getById($id)
    {
        return $this->db->get_where('tindakan', ['id' => $id])->row();
    }

    public function insert($data)
    {
        $this->db->insert('tindakan', [
            'nama' => $data['nama']
        ]);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id)->update('tindakan', [
            'nama' => $data['nama']
        ]);
    }

    public function delete($id)
    {
        $this->db->delete('tindakan', ['id' => $id]);
    }
}