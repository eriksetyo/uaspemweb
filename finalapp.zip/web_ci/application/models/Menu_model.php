<?php
class Menu_model extends CI_Model
{
    public function getMenuByUser($id_user)
    {
        return $this->db->select('tbl_menu.*')
            ->from('tbl_user_menu')
            ->join('tbl_menu', 'tbl_user_menu.id_menu = tbl_menu.id')
            ->where('tbl_user_menu.id_user', $id_user)
            ->get()->result();
    }
}