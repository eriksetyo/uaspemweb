<?php
class Mahasiswa_model extends CI_model
{
    public function Get_mahasiswa()
    {
        //$data = $this->db->get('mahasiswa')->result();
        $this->db->select('mhs.nim, mhs.nama, prodi.nama as prodi');
        $this->db->from('mahasiswa mhs');
        $this->db->join('prodi', 'prodi.id = mhs.id_prodi', 'left');
        $data = $this->db->get();
        return $data;
    }
}
