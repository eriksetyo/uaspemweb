<?php
class Pasien_model extends CI_Model
{
    public function getAll()
    {
        return $this->db->get('pasien')->result();
    }

    public function getById($norm)
    {
        return $this->db->get_where('pasien', ['norm' => $norm])->row();
    }

    public function insert($data)
    {
        $this->db->insert('pasien', [
            'norm' => $data['norm'],
            'nama' => $data['nama'],
            'notelp' => $data['notelp'],
            'alamat' => $data['alamat']
        ]);
    }

    public function update($norm, $data)
    {
        $this->db->where('norm', $norm)->update('pasien', [
            'nama' => $data['nama'],
            'notelp' => $data['notelp'],
            'alamat' => $data['alamat']
        ]);
    }

    public function delete($norm)
    {
        $this->db->delete('pasien', ['norm' => $norm]);
    }
}