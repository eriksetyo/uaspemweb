<?php
class Dokter_model extends CI_Model
{
    public function getAll()
    {
        return $this->db->get('dokter')->result();
    }

    public function getById($id)
    {
        return $this->db->get_where('dokter', ['id' => $id])->row();
    }

    public function insert($data)
    {
        $this->db->insert('dokter', [
            'nama' => $data['nama'],
            'notelp' => $data['notelp']
        ]);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id)->update('dokter', [
            'nama' => $data['nama'],
            'notelp' => $data['notelp']
        ]);
    }

    public function delete($id)
    {
        $this->db->delete('dokter', ['id' => $id]);
    }
}