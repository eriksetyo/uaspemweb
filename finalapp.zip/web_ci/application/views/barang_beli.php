<html>

<body>
    <h1>Transaksi pembelian barang</h1>
    <form method="post" action="Save_pembelian">
        <table>

            <tr>
                <td>No.Faktur</td>
                <td>
                    <input type="text" name="nofaktur">
                </td>
            </tr>

            <tr>
                <td>Tanggal</td>
                <td>
                    <input type="date" name="tanggal">
                </td>
            </tr>

            <tr>
                <td> Nama Barang </td>
                <td>
                    <select name="kode_barang">
                        <?php foreach ($barang as $rows) { ?>
                            <option value="<?php echo $rows->kode_barang; ?>">
                                <?php echo $rows->nama_barang; ?></option>
                        <?php } ?>
                    </select>
                </td>
            </tr>

            <tr>
                <td>Harga</td>
                <td>
                    <input type="text" name="harga">
                </td>
            </tr>

            <tr>
                <td>QTY</td>
                <td>
                    <input type="text" name="qty">
                </td>
            </tr>
            <tr>
                <td><input type="submit" value="Simpan"></td>
            </tr>
        </table>
    </form>
</body>

</html>