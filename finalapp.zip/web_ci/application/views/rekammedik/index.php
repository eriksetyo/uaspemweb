<h3>Data Rekam Medik</h3>
<a href="<?= site_url('RekamMedik/rekammedik/create') ?>" class="btn btn-primary mb-3">+ Tambah Rekam Medik</a>

<?php if (!empty($message)) : ?>
<?= $message ?>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Tanggal</th>
            <th>Pasien</th>
            <th>Dokter</th>
            <th>Tindakan</th>
            <th>Visum</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($rekammedik as $r): ?>
        <tr>
            <td><?= $r->tanggal ?></td>
            <td><?= $r->pasien ?></td>
            <td><?= $r->dokter ?></td>
            <td><?= $r->tindakan ?></td>
            <td><?= $r->visum ?></td>
            <td>
                <a href="<?= site_url('RekamMedik/rekammedik/edit/'.$r->id) ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="<?= site_url('RekamMedik/rekammedik/delete/'.$r->id) ?>"
                    onclick="return confirm('Yakin hapus?')" class="btn btn-sm btn-danger">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>