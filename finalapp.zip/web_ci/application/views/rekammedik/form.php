<h3><?= isset($data) ? 'Edit' : 'Tambah' ?> Rekam Medik</h3>

<form method="post"
    action="<?= isset($data) ? site_url('RekamMedik/rekammedik/update/'.$data->id) : site_url('RekamMedik/rekammedik/store') ?>">
    <div class="form-group">
        <label>Tanggal</label>
        <input type="date" name="tanggal" class="form-control" value="<?= isset($data) ? $data->tanggal : '' ?>"
            required>
    </div>

    <div class="form-group">
        <label>Pasien</label>
        <select name="norm" class="form-control" required>
            <?php foreach ($pasien as $p): ?>
            <option value="<?= $p->norm ?>" <?= isset($data) && $data->norm == $p->norm ? 'selected' : '' ?>>
                <?= $p->nama ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Dokter</label>
        <select name="id_dokter" class="form-control" required>
            <?php foreach ($dokter as $d): ?>
            <option value="<?= $d->id ?>" <?= isset($data) && $data->id_dokter == $d->id ? 'selected' : '' ?>>
                <?= $d->nama ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Tindakan</label>
        <select name="id_tindakan" class="form-control" required>
            <?php foreach ($tindakan as $t): ?>
            <option value="<?= $t->id ?>" <?= isset($data) && $data->id_tindakan == $t->id ? 'selected' : '' ?>>
                <?= $t->nama ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Visum</label>
        <input type="text" name="visum" class="form-control" value="<?= isset($data) ? $data->visum : '' ?>">
    </div>

    <div class="form-group">
        <label>Keterangan Tindakan</label>
        <input type="text" name="tindakan" class="form-control" value="<?= isset($data) ? $data->tindakan : '' ?>">
    </div>

    <br>
    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="<?= site_url('RekamMedik/rekammedik') ?>" class="btn btn-secondary">Kembali</a>
</form>