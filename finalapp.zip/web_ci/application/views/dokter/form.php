<form
    action="<?= isset($data) ? site_url('RekamMedik/dokter/update/'.$data->id) : site_url('RekamMedik/dokter/store') ?>"
    method="post">
    <div class="form-group">
        <label>Nama Dokter</label>
        <input type="text" name="nama" class="form-control" value="<?= @$data->nama ?>" required>
    </div>
    <div class="form-group">
        <label>No. Telepon</label>
        <input type="text" name="notelp" class="form-control" value="<?= @$data->notelp ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
</form>