<div class="container-fluid">
    <!--begin::Row-->
    <div class="row g-4">
        <!--begin::Col-->
        <div class="col-md-12">
            <!--begin::Quick Example-->
            <div class="card card-primary card-outline mb-4">
                <!--begin::Header-->
                <div class="card-header">
                    <div class="card-title">Form Jenis Bayar</div>
                </div>
                <!--end::Header-->
                <!--begin::Form-->

                <!-- <form action="http://127.0.0.1/web_ci/index.php/index.php/kelas2b/Jenisbayar/Insert"
                    enctype="multipart/form-data" method="post" accept-charset="utf-8"> -->

                <?php echo form_open_multipart('kelas2b/Jenisbayar/Insert'); ?>
                <!--begin::Body-->
                <div class="card-body">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nama Jenis</label>
                        <?php echo inputan('text', 'nama', 'form-control', 'Jenis Pembayaran', 1, '', ''); ?>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nominal</label>
                        <?php echo inputan('text', 'nominal', 'form-control', 'Nominal', 1, '', ''); ?>
                    </div>
                </div>
                <!--end::Body-->
                <!--begin::Footer-->
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <!--end::Footer-->
                <!-- </form> -->
                <!--end::Form-->
            </div>
            <!--end::Quick Example-->
        </div>
        <!--end::Col-->
    </div>
    <!--end::Row-->
</div>