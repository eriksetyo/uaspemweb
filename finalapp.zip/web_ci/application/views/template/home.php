<div class="row">
    <!-- Info Boxes -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3><?= $total_rekammedik ?></h3>
                <p>Total Rekam Medik</p>
            </div>
            <div class="icon">
                <i class="bi bi-journal-medical"></i>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3><?= $total_pasien ?></h3>
                <p>Total Pasien</p>
            </div>
            <div class="icon">
                <i class="bi bi-people-fill"></i>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3><?= $total_dokter ?></h3>
                <p>Total Dokter</p>
            </div>
            <div class="icon">
                <i class="bi bi-person-badge"></i>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner">
                <h3><?= $total_tindakan ?></h3>
                <p>Total Tindakan</p>
            </div>
            <div class="icon">
                <i class="bi bi-heart-pulse"></i>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left Column: Grafik -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Rekam Medik per Bulan</h3>
            </div>
            <div class="card-body" style="min-height: 300px;">
                <div id="rekammedikChart"></div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <h3 class="card-title">Distribusi Tindakan</h3>
            </div>
            <div class="card-body" style="min-height: 300px;">
                <div id="tindakanChart"></div>
            </div>
        </div>
    </div>

    <!-- Right Column: List Dokter dan Pasien -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Dokter dengan Pasien Terbanyak</h3>
            </div>
            <div class="card-body">
                <ul class="list-group">
                    <?php foreach($dokter_terbanyak as $dokter): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= htmlspecialchars($dokter->nama) ?>
                        <span class="badge bg-primary rounded-pill"><?= $dokter->pasien_count ?> pasien</span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <h3 class="card-title">Pasien Terbaru</h3>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>No HP</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pasien_terbaru as $pasien): ?>
                        <tr>
                            <td><?= htmlspecialchars($pasien->nama) ?></td>
                            <td><?= htmlspecialchars($pasien->notelp ?? '-') ?></td>
                            <td><?= htmlspecialchars($pasien->alamat ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Sesuaikan icon di .small-box supaya lebih besar dan tidak terlalu menempel */
.small-box .icon {
    font-size: 3rem;
    color: rgba(255, 255, 255, 0.7);
    top: 15px;
    right: 15px;
    position: absolute;
    transition: color 0.3s ease;
}

.small-box:hover .icon {
    color: rgba(255, 255, 255, 1);
}

.small-box {
    position: relative;
    padding: 15px;
    overflow: hidden;
    border-radius: 0.25rem;
    color: #fff;
}

.small-box .inner h3 {
    font-weight: 700;
    font-size: 2.5rem;
    margin: 0;
}

.card-header h3.card-title {
    font-weight: 600;
    font-size: 1.25rem;
}

/* Sesuaikan tabel supaya lebih rapih */
.table-striped tbody tr:nth-of-type(odd) {
    background-color: #f8f9fa;
}

/* Scroll untuk tabel jika data banyak */
.card-body.p-0 {
    max-height: 300px;
    overflow-y: auto;
}

/* Buat badge dokter pasien lebih kontras */
.badge.bg-primary {
    font-size: 0.9rem;
    padding: 0.4em 0.75em;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Line Chart Rekam Medik per Bulan (ApexCharts)
    var optionsLine = {
        chart: {
            type: 'area',
            height: 300,
            toolbar: {
                show: false
            }
        },
        series: [{
            name: 'Jumlah Rekam Medik',
            data: <?= json_encode($grafik['jumlah']) ?>
        }],
        xaxis: {
            categories: <?= json_encode($grafik['bulan']) ?>,
            labels: {
                rotate: -45
            }
        },
        stroke: {
            curve: 'smooth'
        },
        fill: {
            opacity: 0.3,
            type: 'solid'
        },
        dataLabels: {
            enabled: false
        },
        yaxis: {
            min: 0,
            forceNiceScale: true
        },
        tooltip: {
            enabled: true
        }
    };
    var chartLine = new ApexCharts(document.querySelector("#rekammedikChart"), optionsLine);
    chartLine.render();

    // Pie Chart Distribusi Tindakan (ApexCharts)
    var optionsPie = {
        chart: {
            type: 'donut',
            height: 300
        },
        series: <?= json_encode($grafikTindakan['jumlah']) ?>,
        labels: <?= json_encode($grafikTindakan['labels']) ?>,
        colors: [
            '#0d6efd', '#198754', '#ffc107', '#dc3545', '#0dcaf0',
            '#6c757d', '#fd7e14', '#6610f2', '#20c997', '#e83e8c'
        ],
        legend: {
            position: 'bottom'
        },
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 300
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    };
    var chartPie = new ApexCharts(document.querySelector("#tindakanChart"), optionsPie);
    chartPie.render();
});
</script>