<?php
$segment1 = $this->uri->segment(1); // Contoh: 'welcome', 'RekamMedik', dll
$segment2 = $this->uri->segment(2); // Contoh: 'Rekammedik', 'Dokter', 'Pasien', dll
?>

<div class="sidebar-wrapper">
    <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

            <!-- Dashboard -->
            <!-- Dashboard tanpa submenu -->
            <li class="nav-item">
                <a href="<?= base_url('index.php/welcome'); ?>"
                    class="nav-link <?= ($segment1 == 'welcome' && !$segment2) ? 'active' : '' ?>">
                    <i class="nav-icon bi bi-speedometer"></i>
                    <p>Dashboard</p>
                </a>
            </li>

            <!-- Group Rekam Medik -->
            <li class="nav-item <?= ($segment1 == 'RekamMedik') ? 'menu-open' : '' ?>">
                <a href="#" class="nav-link <?= ($segment1 == 'RekamMedik') ? 'active' : '' ?>">
                    <i class="nav-icon bi bi-clipboard2-pulse-fill text-success"></i>
                    <p>
                        Rekam Medik
                        <i class="nav-arrow bi bi-chevron-right"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview"
                    style="<?= ($segment1 == 'RekamMedik') ? 'display: block;' : 'display: none;' ?>">
                    <li class="nav-item">
                        <a href="<?= base_url('index.php/RekamMedik/Rekammedik'); ?>"
                            class="nav-link <?= ($segment2 == 'Rekammedik') ? 'active' : '' ?>">
                            <i class="nav-icon bi bi-circle"></i>
                            <p>Data Rekam</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url('index.php/RekamMedik/Dokter'); ?>"
                            class="nav-link <?= ($segment2 == 'Dokter') ? 'active' : '' ?>">
                            <i class="nav-icon bi bi-circle"></i>
                            <p>Dokter</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url('index.php/RekamMedik/Pasien'); ?>"
                            class="nav-link <?= ($segment2 == 'Pasien') ? 'active' : '' ?>">
                            <i class="nav-icon bi bi-circle"></i>
                            <p>Pasien</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url('index.php/RekamMedik/Tindakan'); ?>"
                            class="nav-link <?= ($segment2 == 'Tindakan') ? 'active' : '' ?>">
                            <i class="nav-icon bi bi-circle"></i>
                            <p>Tindakan</p>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Menu lain bisa ditambahkan disini -->

        </ul>
    </nav>
</div>