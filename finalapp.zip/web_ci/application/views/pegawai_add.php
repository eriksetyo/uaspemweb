<html>

<body>
	<form method="post" action="Save">
		<label>NIP</label>
		<input type="text" name="nip"> <br>

		<label>Nama</label>
		<input type="text" name="nama"> <br>

		<label>Jabatan</label>
		<select name="id_jabatan">
			<?php
			foreach ($jabatan as $_row) {
			?>
				<option value="<?= $_row->id; ?>"><?= $_row->nama; ?> </option>
			<?php } ?>

		</select>
		<br>

		<label>No.Telp</label>
		<input type="text" name="no_telp">

		<input type="submit" value="Simpan">
	</form>

</body>

</html>