<html>

<body>
	<form method="post" action="Save">
		<table>
			
			<tr>
				<td>Kode 1</td>
				<td>
					<input type="text" name="kode_barang">
				</td>
			</tr>
			<tr>
				<td>Kode 2</td>
				<td>
					<!-- 
					inputan($type, $name, $class,$placeholder,
	$required, $values, $tags)
					-->
					
					<?php echo inputan('text', 'nama','col-sm-8','Nama Lengkap ..', 1, '',''); ?>

				</td>
			</tr>
			
		</table>
	</form>
</body>

</html>