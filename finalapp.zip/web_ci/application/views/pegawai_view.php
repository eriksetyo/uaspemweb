<?php
echo $nip . " " . $nama . " " . $no_telp;
/*
echo "<h1>Load Dari Controller</h1>";
echo "<table>" .
    "<tr>" .
    "<th>No.</th>" .
    "<th>NIP</th>" .
    "<th>Nama</th>" .
    "<th>Jabatan</th>".
    "<th>No.Telp</th>" .
    "</tr>";
$no = 1;
foreach ($pegawai as $_pegawai) {
    echo "<tr>" .
        "<td>" . $no . "</td>" .
        "<td>" . $_pegawai->nip . "</td>" .
        "<td>" . $_pegawai->nama . "</td>" .
        "<td>" . $_pegawai->nama . "</td>" .
        "<td>" . $_pegawai->no_telp . "</td>" .
        "</tr>";
    $no++;
}
echo "</table>";*/

echo "<h1><b>Load Dari Model</b></h1>";
echo "<a href='pegawai/add'> <button>Add Pegawai</button>  </a>";
echo "<table>" .
    "<tr>" .
    "<th>No.</th>" .
    "<th>NIP</th>" .
    "<th>Nama</th>" .
    "<th>Jabatan</th>" .
    "<th>No.Telp</th>" .
    "<th>Edit</th>" .
    "<th>Hapus</th>" .
    "</tr>";
$no = 1;
foreach ($pegawai_model as $_pegawai_model) {
    echo "<tr>" .
        "<td>" . $no . "</td>" .
        "<td>" . $_pegawai_model->nip . "</td>" .
        "<td>" . $_pegawai_model->nama . "</td>" .
        "<td>" . $_pegawai_model->jabatan . "</td>" .
        "<td>" . $_pegawai_model->no_telp . "</td>" .
        "<td><a href='Pegawai/Edit/$_pegawai_model->nip'>Edit Data</a></td>" .
        "<td><a href='Pegawai/Delete/$_pegawai_model->nip'>Hapus Data</a></td>" .
        "</tr>";
    $no++;
}
echo "</table>";
