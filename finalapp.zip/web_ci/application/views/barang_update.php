<html>

<body>
	<?= form_open(base_url('index.php/Barang/Update')) ?>
	<?php foreach ($barang as $_barang); ?>
	<table>
		<tr>
			<td> Group Barang </td>
			<td>
				<select name="id_group">
					<?php foreach ($group as $_group) { ?>
						<option value="<?php echo $_group->id; ?>"
							<?php if ($_barang->id_group == $_group->id) {
								echo "selected";
							} ?>><?php echo $_group->nama; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<tr>
			<td>Kode</td>
			<td>
				<input type="text" name="kode_barang" value="<?php echo $_barang->kode_barang; ?>">
			</td>
		</tr>
		<tr>
			<td>Nama Barang</td>
			<td>
				<input type="text" name="nama_barang" value="<?php echo $_barang->nama_barang; ?>">
			</td>
		</tr>
		<tr>
			<td>Harga</td>
			<td>
				<input type="text" name="harga" value="<?php echo $_barang->harga; ?>">
			</td>
		</tr>
		<tr>
			<td><input type="submit" value="Simpan"></td>
		</tr>
	</table>
	</form>
</body>

</html>