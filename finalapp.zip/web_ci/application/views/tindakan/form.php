<h3><?= isset($data) ? 'Edit Tindakan' : 'Tambah Tindakan' ?></h3>
<form
    action="<?= isset($data) ? site_url('RekamMedik/tindakan/update/' . $data->id) : site_url('RekamMedik/tindakan/store') ?>"
    method="post">
    <div class="form-group">
        <label>Nama Tindakan</label>
        <input type="text" name="nama" class="form-control" value="<?= isset($data) ? $data->nama : '' ?>" required>
    </div>
    <br>
    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="<?= site_url('RekamMedik/tindakan') ?>" class="btn btn-secondary">Kembali</a>
</form>