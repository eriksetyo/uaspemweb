<h3>Data Tindakan</h3>
<a href="<?= site_url('RekamMedik/tindakan/create') ?>" class="btn btn-primary mb-2">Tambah Tindakan</a>
<?php if (!empty($message)) : ?>
<?= $message ?>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Tindakan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($tindakan as $i => $row): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><?= $row->nama ?></td>
            <td>
                <a href="<?= site_url('RekamMedik/tindakan/edit/' . $row->id) ?>"
                    class="btn btn-sm btn-warning">Edit</a>
                <a href="<?= site_url('RekamMedik/tindakan/delete/' . $row->id) ?>" class="btn btn-sm btn-danger"
                    onclick="return confirm('Hapus data?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach ?>
    </tbody>
</table>