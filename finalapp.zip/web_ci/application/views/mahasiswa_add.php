<html>


<body>
	<?= form_open('Mahasiswa/Save'); ?>
	<table>
		<tr>
			<td>NIM</td>
			<td>
				<input type="text" name="nim" required>
			</td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>
				<input type="text" name="nama" required>
			</td>
		</tr>
		<tr>
			<td>Prodi</td>
			<td>
				<select name="id_prodi">
					<?php foreach ($prodi as $_prodi) { ?>
						<option value="<?= $_prodi->id; ?>"> <?= $_prodi->nama; ?> </option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<tr>
			<td>
				<input type="submit" Value="Simpan">
			</td>
		</tr>
	</table>
	</form>
</body>

</html>