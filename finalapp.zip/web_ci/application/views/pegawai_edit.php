<html>

<body>
	<?php foreach ($pegawai as $rows); ?>
	<table>
		<form method="post" action="<?= base_url('index.php/Pegawai/Update'); ?>">
			<tr>
				<td> <label>NIP</label> </td>
				<td> <input type="text" name="nip" value="<?= $rows->nip; ?>"></td>
			</tr>

			<tr>
				<td><label>Nama</label></td>
				<td> <input type="text" name="nama" value="<?= $rows->nama; ?>"></td>
			</tr>
			<tr>
				<td><label>Jabatan</label></td>
				<td>
					<select name="id_jabatan">
						<?php
						foreach ($jabatan as $_row) {
						?>
							<option value="<?= $_row->id; ?>"><?= $_row->nama; ?> </option>
						<?php } ?>

					</select>
				</td>
			</tr>
			<tr>
				<td> <label>No.Telp</label> </td>
				<td> <input type="text" name="no_telp" value="<?= $rows->no_telp; ?>"></td>
			</tr>
			<tr>
				<td> <input type="submit" value="Update"> </td>
			</tr>
		</form>
	</table>
</body>

</html>