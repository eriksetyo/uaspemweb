<?php
echo $nim . " " . $nama;
