<?php
echo "<a href=" . base_url('index.php/Barang/Add') . "> <button>Add Barang</button>  </a>";
echo "<a href=" . base_url('index.php/Barang/Beli') . "> <button>Pembelian Barang</button>  </a>";
echo "<table border='1'> <tr>" .
    "<th>No.</th>" .
    "<th>Group</th>" .
    "<th>Kode Barang</th>" .
    "<th>Nama Barang</th>" .
    "<th>Harga</th>" .
    "<th>Stock</th>" .
    "<th>Edit Data</th>" .
    "<th>Hapus Data</th>";
$no = 1;
foreach ($barang_model as $_barang_model) {
    echo "<tr>" .
        "<td>" . $no . "</td>" .
        "<td>" . $_barang_model->group_barang . "</td>" .
        "<td>" . $_barang_model->kode_barang . "</td>" .
        "<td>" . $_barang_model->nama_barang . "</td>" .
        "<td>" . number_format($_barang_model->harga) . "</td>" .
        "<td>" . number_format($_barang_model->stock) . "</td>" .
        "<td> <a href='Barang/Edit/$_barang_model->kode_barang'>Edit Data</td>" .
        "<td> <a href='Barang/Hapus/$_barang_model->kode_barang'>Hapus Data</td>" .
        "</tr>";
    $no++;
}
echo "</table>";
