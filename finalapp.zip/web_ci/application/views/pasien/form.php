<form
    action="<?= isset($data) ? site_url('RekamMedik/pasien/update/'.$data->norm) : site_url('RekamMedik/pasien/store') ?>"
    method="post">
    <div class="form-group">
        <label>No RM</label>
        <input type="text" name="norm" class="form-control" value="<?= @$data->norm ?>"
            <?= isset($data) ? 'readonly' : '' ?> required>
    </div>
    <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control" value="<?= @$data->nama ?>" required>
    </div>
    <div class="form-group">
        <label>No. Telepon</label>
        <input type="text" name="notelp" class="form-control" value="<?= @$data->notelp ?>">
    </div>
    <div class="form-group">
        <label>Alamat</label>
        <textarea name="alamat" class="form-control"><?= @$data->alamat ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
</form>