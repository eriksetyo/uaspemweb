<h3>Data Pasien</h3>
<a href="<?= site_url('RekamMedik/pasien/create') ?>" class="btn btn-primary mb-2">Tambah Pasien</a>
<?php if (!empty($message)) : ?>
<?= $message ?>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>No RM</th>
            <th>Nama Pasien</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($pasien as $i => $row): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><?= $row->norm ?></td>
            <td><?= $row->nama ?></td>
            <td>
                <a href="<?= site_url('RekamMedik/pasien/edit/' . $row->norm) ?>"
                    class="btn btn-sm btn-warning">Edit</a>
                <a href="<?= site_url('RekamMedik/pasien/delete/' . $row->norm) ?>" class="btn btn-sm btn-danger"
                    onclick="return confirm('Hapus data?')">Hapus</a>

            </td>
        </tr>
        <?php endforeach ?>
    </tbody>
</table>