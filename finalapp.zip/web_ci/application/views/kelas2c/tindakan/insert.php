 <div class="container-fluid">
     <!-- Info boxes -->
     <!--begin::Row-->
     <div class="col-md-12">
         <!--begin::Quick Example-->
         <div class="card card-primary card-outline mb-4">
             <!--begin::Header-->
             <div class="card-header">
                 <div class="card-title">Jenis Tindakan</div>
             </div>
             <!--end::Header-->
             <!--begin::Form-->
             <?php echo form_open_multipart('Tindakan/insert'); ?>
             <!--begin::Body-->
             <div class="card-body">
                 <div class="mb-3">
                     <label for="text" class="form-label">Nama Tindakan</label>
                     <input
                         type="text"
                         class="form-control"
                         id="nama"
                         name="nama" />
                 </div>
             </div>
             <!--end::Body-->
             <!--begin::Footer-->
             <div class="card-footer">
                 <button type="submit" class="btn btn-primary">Submit</button>
             </div>
             <!--end::Footer-->
             </form>
             <!--end::Form-->
         </div>
         <!--end::Row-->
     </div>
 </div>