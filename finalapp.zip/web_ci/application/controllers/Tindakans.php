<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tindakan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('ses_masuk') != TRUE) {
            $url = base_url();
            redirect($url);
        };
    }

    public function index()
    {
        $this->template->load('template/dashboard', 'kelas2c/tindakan/insert');
    }

    public function insert()
    {
        $nama    = $this->input->post('nama');
        $data = array(
            'nama'    => $nama
        );
        //print_r($data);
        $this->db->insert('tindakan', $data);
        echo "<meta http-equiv='refresh' content='0; url=" . base_url() . "index.php/Welcome'>";
    }
}
