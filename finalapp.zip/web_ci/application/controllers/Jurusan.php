<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jurusan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('ses_masuk') != TRUE) {
            $url = base_url();
            redirect($url);
        };
    }

    public function index()
    {
        $this->template->load('template/dashboard', 'kelas2b/jurusan/insert');
    }

    public function insert()
    {
        $nama    = $this->input->post('nama');
        $data = array(
            'nama'    => $nama
        );
        $this->db->insert('jurusan', $data);
        echo "<meta http-equiv='refresh' content='0; url=" . base_url() . "index.php/welcome'>";
    }


    public function Session_form()
    {
        $this->template->load('template/dashboard', 'session_form');
    }

    public function Save_session()
    {
        $user_nama     = $this->input->post('user_name');
        $password    = $this->input->post('pswd');

        $this->session->set_userdata('user_nama', $user_nama);
        $this->session->set_userdata('pswd', $password);
    }

    public function Sigout()
    {
        $this->session->unset_userdata('ses_email');
        $this->session->unset_userdata('ses_masuk');
        echo "<meta http-equiv='refresh' content='0; url=" . base_url() . "index.php'>";
    }

    public function supplier()
    {
        $this->template->load('template/dashboard', 'data_pendukung/supplier');
    }

    public function jenis_barang()
    {
        $this->template->load('template/dashboard', 'data_pendukung/jenis_barang');
    }

    public function barang()
    {
        $this->template->load('template/dashboard', 'data_pendukung/barang');
    }
}
