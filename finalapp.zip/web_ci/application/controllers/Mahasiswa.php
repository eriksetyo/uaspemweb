<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mahasiswa extends CI_Controller
{


	public function index()
	{
		$data['nim']    = '2013030043';
		$data['nama']   = 'M. Mukhtar Fuadi';

		$data['nim']    = '2013030079';
		$data['nama']   = 'Muhammad Afif Davitra Aditya Putra';

		$data['nim']    = '2213030078';
		$data['nama']   = 'Pashkah Immada Rizky';
		//print_r($mahasiswa);
		//$data['data'] = $mahasiswa;
		//print_r($data);
		$this->load->view('penggunaan_array_view', $data);
	}

	public function Data_mahasiswa()
	{
		$this->load->model('Mahasiswa_model');
		//$data['mahasiswa']          = $this->db->get('mahasiswa')->result();
		//print_r($data);
		$data['mahasiswa_model']    = $this->Mahasiswa_model->Get_mahasiswa()->result();
		$this->load->view('data_mahasiswa', $data);
	}

	public function Add()
	{
		$data['prodi']	= $this->db->get('prodi')->result();
		$this->load->view('mahasiswa_add', $data);
	}

	public function Save()
	{
		$nim 		= $this->input->post('nim');
		$nama		= $this->input->post('nama');
		$id_prodi	= $this->input->post('id_prodi');

		//Validasi berdasrkan NIM
		$validasi = $this->db->get_where(
			'mahasiswa',
			array('nim' => $nim)
		)->result();

		if (count($validasi) > 0) {
			foreach ($validasi as $rows);
			echo "<script>alert('NIM $rows->nim atas nama $rows->nama sudah digunakan')</script>";
		} else {
			// baris code untuk simpan data
			$data = array(
				'nim' 		=> $nim,
				'nama'		=> $nama,
				'id_prodi'	=> $id_prodi
			);
			$this->db->insert('mahasiswa', $data);
			redirect('Mahasiswa/Data_mahasiswa');
		}
	}

	public function Edit()
	{
		// http://127.0.0.1/web_ci/index.php/Penggunaan_array/Edit/2013030043

		//echo "Segment 1 = ".$this->uri->segment(1)."<br>";
		//echo "Segment 2 = ".$this->uri->segment(2)."<br>";
		//echo "Segment 3 = ".$this->uri->segment(3)."<br>";
		$nim = $this->uri->segment(3);

		//$this->db->get_where('mahasiswa',array('nim'=>$nim));
		//echo $this->db->last_query();

		$data['prodi']	= $this->db->get('prodi')->result();
		$data['mahasiswa'] = $this->db->get_where('mahasiswa', array('nim' => $nim))->result();

		$this->load->view('mahasiswa_edit', $data);
	}

	public function Update()
	{
		// variabe old_nim
		$old_nim = $this->input->post('old_nim');

		$nim 	= $this->input->post('nim');
		$nama	= $this->input->post('nama');
		$id_prodi	= $this->input->post('id_prodi');

		$data = array(
			'nim' 		=> $nim,
			'nama'		=> $nama,
			'id_prodi'	=> $id_prodi
		);

		// Cek apakah old_nim dan nim sama atau tidak
		// Jika tidak sama maka lakukakan update data

		if ($old_nim == $nim) {
			//echo "Disini";
			$this->db->where('nim', $nim);
			$this->db->update('mahasiswa', $data);
			redirect('Mahasiswa/Data_mahasiswa');
		} else {
			// Validasi nim baru
			// Jika nim baru sudah ada maka tampilkan pesan
			$validasi = $this->db->get_where(
				'mahasiswa',
				array('nim' => $nim)
			)->result();

			if (count($validasi) > 0) {
				// NIM baru sudah digunakan
				echo "<script>alert('NIM Yang dimasukkan sudah digunakan')</script>";
				//redirect('Penggunaan_array/Edit/'.$nim);
			} else {
				// Jika nim baru tidak ada maka lakukan proses update
				$this->db->where('nim', $nim);
				$this->db->update('mahasiswa', $data);
				redirect('Mahasiswa/Data_mahasiswa');
			}
		}
	}

	public function Hapus()
	{
		$nim = $this->uri->segment(3);

		$this->db->where('nim', $nim);
		$this->db->delete('mahasiswa');

		redirect('Penggunaan_array/Data_mahasiswa');
	}
}
