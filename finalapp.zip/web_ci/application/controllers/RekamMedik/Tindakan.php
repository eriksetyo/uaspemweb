<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tindakan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Tindakan_model');
        $this->load->library('session');
    }

    public function index()
    {
        $data['tindakan'] = $this->Tindakan_model->getAll();
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Tindakan', 'url' => '']
        ];
        $data['message'] = $this->session->flashdata('message');
        $this->template->load('template/dashboard', 'tindakan/index', $data);
    }

    public function create()
    {
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Tindakan', 'url' => site_url('RekamMedik/tindakan')],
            ['label' => 'Tambah', 'url' => '']
        ];
        $this->template->load('template/dashboard', 'tindakan/form', $data);
    }

    public function store()
    {
        $postData = $this->input->post(null, true);

        $this->Tindakan_model->insert($postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil disimpan.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menyimpan data.</div>');
        }
        redirect('RekamMedik/tindakan');
    }

    public function edit($id)
    {
        $data['data'] = $this->Tindakan_model->getById($id);
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Tindakan', 'url' => site_url('RekamMedik/tindakan')],
            ['label' => 'Edit', 'url' => '']
        ];
        $this->template->load('template/dashboard', 'tindakan/form', $data);
    }

    public function update($id)
    {
        $postData = $this->input->post(null, true);

        $this->Tindakan_model->update($id, $postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil diupdate.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal mengupdate data atau tidak ada perubahan.</div>');
        }
        redirect('RekamMedik/tindakan');
    }

    public function delete($id)
    {
        $this->Tindakan_model->delete($id);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil dihapus.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menghapus data.</div>');
        }
        redirect('RekamMedik/tindakan');
    }
}