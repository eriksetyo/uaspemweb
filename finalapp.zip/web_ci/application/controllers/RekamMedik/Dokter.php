<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dokter extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Dokter_model');
        $this->load->library('session');
    }

    public function index()
    {
        $data['dokter'] = $this->Dokter_model->getAll();
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Dokter', 'url' => '']
        ];
        $data['message'] = $this->session->flashdata('message');
        $this->template->load('template/dashboard', 'dokter/index', $data);
    }

    public function create()
    {
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Dokter', 'url' => site_url('RekamMedik/dokter')],
            ['label' => 'Tambah', 'url' => '']
        ];
        $this->template->load('template/dashboard', 'dokter/form', $data);
    }

    public function store()
    {
        $postData = $this->input->post(null, true);

        $this->Dokter_model->insert($postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil disimpan.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menyimpan data.</div>');
        }
        redirect('RekamMedik/dokter');
    }

    public function edit($id)
    {
        $data['data'] = $this->Dokter_model->getById($id);
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Dokter', 'url' => site_url('RekamMedik/dokter')],
            ['label' => 'Edit', 'url' => '']
        ];
        $this->template->load('template/dashboard', 'dokter/form', $data);
    }

    public function update($id)
    {
        $postData = $this->input->post(null, true);

        $this->Dokter_model->update($id, $postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil diupdate.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal mengupdate data atau tidak ada perubahan.</div>');
        }
        redirect('RekamMedik/dokter');
    }

    public function delete($id)
    {
        $this->Dokter_model->delete($id);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil dihapus.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menghapus data.</div>');
        }
        redirect('RekamMedik/dokter');
    }
}