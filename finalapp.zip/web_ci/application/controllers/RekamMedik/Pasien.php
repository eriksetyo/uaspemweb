<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pasien extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pasien_model');
        $this->load->library('session');
    }

    public function index()
    {
        $data['pasien'] = $this->Pasien_model->getAll();
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Pasien', 'url' => '']
        ];
        $data['message'] = $this->session->flashdata('message');
        $this->template->load('template/dashboard', 'pasien/index', $data);
    }

    public function create()
    {
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Pasien', 'url' => site_url('RekamMedik/pasien')],
            ['label' => 'Tambah', 'url' => '']
        ];
        $this->template->load('template/dashboard', 'pasien/form', $data);
    }

    public function store()
    {
        $postData = $this->input->post(null, true);

        $this->Pasien_model->insert($postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil disimpan.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menyimpan data.</div>');
        }
        redirect('RekamMedik/pasien');
    }

    public function edit($id)
    {
        $data['data'] = $this->Pasien_model->getById($id);
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Pasien', 'url' => site_url('RekamMedik/pasien')],
            ['label' => 'Edit', 'url' => '']
        ];
        $this->template->load('template/dashboard', 'pasien/form', $data);
    }

    public function update($id)
    {
        $postData = $this->input->post(null, true);

        $this->Pasien_model->update($id, $postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil diupdate.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal mengupdate data atau tidak ada perubahan.</div>');
        }
        redirect('RekamMedik/pasien');
    }

    public function delete($id)
    {
        $this->Pasien_model->delete($id);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil dihapus.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menghapus data.</div>');
        }
        redirect('RekamMedik/pasien');
    }
}