<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rekammedik extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Rekammedik_model');
        $this->load->library('session');
    }

    public function index()
    {
        $data['rekammedik'] = $this->Rekammedik_model->getAll();
        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Rekam Medik', 'url' => '']
        ];
        $data['message'] = $this->session->flashdata('message');
        $this->template->load('template/dashboard', 'rekammedik/index', $data);
    }

    public function create()
    {
        $data['dokter'] = $this->Rekammedik_model->getDokter();
        $data['pasien'] = $this->Rekammedik_model->getPasien();
        $data['tindakan'] = $this->Rekammedik_model->getTindakan();

        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Rekam Medik', 'url' => site_url('RekamMedik/rekammedik')],
            ['label' => 'Tambah', 'url' => '']
        ];

        $this->template->load('template/dashboard', 'rekammedik/form', $data);
    }

    public function store()
    {
        $postData = $this->input->post(null, true);

        $this->Rekammedik_model->insert($postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil disimpan.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menyimpan data.</div>');
        }
        redirect('RekamMedik/rekammedik');
    }

    public function edit($id)
    {
        $data['data'] = $this->Rekammedik_model->getById($id);
        $data['dokter'] = $this->Rekammedik_model->getDokter();
        $data['pasien'] = $this->Rekammedik_model->getPasien();
        $data['tindakan'] = $this->Rekammedik_model->getTindakan();

        $data['breadcrumb'] = [
            ['label' => 'Home', 'url' => base_url()],
            ['label' => 'Rekam Medik', 'url' => site_url('RekamMedik/rekammedik')],
            ['label' => 'Edit', 'url' => '']
        ];

        $this->template->load('template/dashboard', 'rekammedik/form', $data);
    }

    public function update($id)
    {
        $postData = $this->input->post(null, true);

        $this->Rekammedik_model->update($id, $postData);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil diupdate.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal mengupdate data atau tidak ada perubahan.</div>');
        }
        redirect('RekamMedik/rekammedik');
    }

    public function delete($id)
    {
        $this->Rekammedik_model->delete($id);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-success">Data berhasil dihapus.</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Gagal menghapus data.</div>');
        }
        redirect('RekamMedik/rekammedik');
    }
}