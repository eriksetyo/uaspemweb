<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('ses_masuk') != TRUE) {
            redirect(base_url());
        }
        $this->load->model('Rekammedik_model');
    }

    public function index()
    {
        $data['total_rekammedik'] = $this->Rekammedik_model->countAll();
        $data['total_pasien'] = $this->Rekammedik_model->countPasien();
        $data['total_dokter'] = $this->Rekammedik_model->countDokter();
        $data['total_tindakan'] = $this->Rekammedik_model->countTindakan();

        $data['grafik'] = $this->Rekammedik_model->grafikBulanan();

        $data['grafikTindakan'] = $this->Rekammedik_model->grafikTindakan();

        $data['dokter_terbanyak'] = $this->Rekammedik_model->getDokterTerbanyakPasien();
        $data['pasien_terbaru'] = $this->Rekammedik_model->getPasienTerbaru();

        // Ambil menu user (sama seperti sebelumnya)
        $id_user = $this->session->userdata('ses_id_user');
        $this->db->select('c.id, c.nama, c.link');
        $this->db->from('tbl_user_menu a');
        $this->db->join('tbl_user b', 'b.id = a.id_user');
        $this->db->join('tbl_menu c', 'c.id = a.id_menu');
        $this->db->where('a.id_user', $id_user);
        $data['menu'] = $this->db->get()->result();

        $this->template->load('template/dashboard', 'template/home', $data);
    }



	public function Session_form()
	{
		$this->template->load('template/dashboard', 'session_form');
	}

	public function Save_session()
	{
		$user_nama 	= $this->input->post('user_name');
		$password	= $this->input->post('pswd');

		$this->session->set_userdata('user_nama', $user_nama);
		$this->session->set_userdata('pswd', $password);
	}

	public function Sigout()
	{
		$this->session->unset_userdata('ses_email');
		$this->session->unset_userdata('ses_masuk');
		echo "<meta http-equiv='refresh' content='0; url=" . base_url() . "index.php'>";
	}

	public function supplier()
	{
		$this->template->load('template/dashboard', 'data_pendukung/supplier');
	}

	public function jenis_barang()
	{
		$this->template->load('template/dashboard', 'data_pendukung/jenis_barang');
	}

	public function barang()
	{
		$this->template->load('template/dashboard', 'data_pendukung/barang');
	}

	public function tangkap_barang()
	{
		$kode 	= $this->input->post('kode');
		$nama	= $this->input->post('nama');
		$harga	= $this->input->post('harga');

		$data = array(
			'kode' 	=> $kode,
			'nama'	=> $nama,
			'harga'	=> $harga
		);
		print_r($data);
	}
}