<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // Pastikan model sudah memuat semua tabel yang diperlukan
        $this->load->model('Rekammedik_model');
    }

    public function index()
    {
        // Data ringkasan
        $data['total_rekammedik'] = $this->db->count_all('rekammedik');
        $data['total_pasien']     = $this->db->count_all('pasien');
        $data['total_dokter']     = $this->db->count_all('dokter');
        $data['total_tindakan']   = $this->db->count_all('tindakan');

        // Data rekam medik terbaru
        $data['recent'] = $this->Rekammedik_model->getRecent(5);

        $this->template->load('template/dashboard', 'dashboard/index', $data);
    }
}