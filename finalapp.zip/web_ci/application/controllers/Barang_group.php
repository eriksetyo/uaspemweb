<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barang_group extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('ses_masuk') != TRUE) {
            $url = base_url();
            redirect($url);
        };
    }

    public function index()
    {
        $this->template->load('template/dashboard', 'kelas2a/barang_group/insert');
    }

    public function insert()
    {
        $nama    = $this->input->post('nama');
        $data = array(
            'nama'    => $nama
        );
        $this->db->insert('barang_group', $data);
        echo "<meta http-equiv='refresh' content='0; url=" . base_url() . "index.php/Welcome'>";
    }
}
