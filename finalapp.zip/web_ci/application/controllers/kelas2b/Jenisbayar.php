<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jenisbayar extends CI_Controller
{
    public function index()
    {
        $this->template->load('template/dashboard', 'kelas2b/master/pembayaran_jenis/insert');
    }

    public function Insert()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('nama', 'Nama Jenis', 'required|trim');
        $this->form_validation->set_rules('nominal', 'Nominal', 'required|numeric|trim');

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {
            $nama = $this->input->post('nama', TRUE);
            $nominal = $this->input->post('nominal', TRUE);

            $data = array(
                'nama'    => $nama,
                'nominal' => $nominal
            );

            $this->db->insert('pembayaran_jenis', $data);
            $this->session->set_flashdata('success', 'Data berhasil disimpan.');
            redirect('kelas2b/Jenisbayar');
        }
    }
}